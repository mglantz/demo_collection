# Ansible Collection - mglantz.demo_collection

This is a demonstration of an Ansible collection.
For more information about how to build your own collections, [click here.](https://docs.ansible.com/ansible/latest/dev_guide/developing_collections_creating.html)

This collection is kept [on GitHub, here.](https://github.com/mglantz/demo_collection)
